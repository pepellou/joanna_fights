$(function() {
    $('button.resign-confirm').remove();
});
